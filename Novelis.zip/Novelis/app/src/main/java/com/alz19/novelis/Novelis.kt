package com.alz19.novelis

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class Novelis : Application()