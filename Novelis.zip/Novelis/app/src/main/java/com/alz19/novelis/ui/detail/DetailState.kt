package com.alz19.novelis.ui.detail

import com.alz19.novelis.model.Story


data class DetailState(
    val story: Story? = null,
)
