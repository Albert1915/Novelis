package com.alz19.novelis.ui.theme

import androidx.compose.ui.graphics.Color

val Beige80 = Color(0xFFF4EEE0)
val Dark40 = Color(0xFF393646)
val Dark80 = Color(0xFF6D5D6E)

val Navy40 = Color(0xFF363062)
val Blue40 = Color(0xFF435385)
val Beige40 = Color(0xFFF5E8C7)